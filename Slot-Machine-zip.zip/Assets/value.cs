//Author: Katie Nuchols

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class value : MonoBehaviour
{
    public Text bal;
    public Text bet;
    public Text input_bet;
    private string input_bal;
    private string bet_set;
    private int balance;
    private int spin_bet;
    public Text slot_0;
    public Text slot_1;
    public Text slot_2;
    public Text win;
    public Text lose;
    private int wins = 0;
    private int loses = 0;
    private int wheel_0;
    private int wheel_1;
    private int wheel_2;
    public float time;
    //set up all of the values that will be used later
    public void ReadStringInput(string s){
        input_bal = s;
        balance = System.Convert.ToInt32(input_bal);
        bal.text = input_bal;//read the input balance from the box
    }

    public void ReadBetInput(){
        bet_set = input_bet.text;
        spin_bet = System.Convert.ToInt32(bet_set);
        bet.text = bet_set;//read the selected bet from the settings
    }

    private void get_spin(){
        wheel_0 = System.Convert.ToInt32(slot_0.text);
        wheel_1 = System.Convert.ToInt32(slot_1.text);
        wheel_2 = System.Convert.ToInt32(slot_2.text);
    }//read the spin wheel output

    private void update_score(){
        win.text = wins.ToString();
        lose.text = loses.ToString();
        bal.text = balance.ToString();
    }//update the variables

    private void check_win_or_lose(){//see if the player won or lost
        if(wheel_0 == wheel_1 && wheel_1 == wheel_2){
            wins++;
            balance = balance + (spin_bet*2);
        }
        else{
            loses++;
            balance = balance - spin_bet;
        }
    }

    public void Play_Game(){//add time delay of screen display and run variables for play
        Invoke ("Game", time);
    }
    void Game(){//game variables that are needed
        get_spin();
        check_win_or_lose();
        update_score();
    }
}
